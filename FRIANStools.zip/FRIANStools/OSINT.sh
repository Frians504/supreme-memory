#!/bin/bash

# Warna
r='\e[1;91m'; g='\e[1;92m'; y='\e[1;93m'; b='\e[1;94m'
p='\e[1;95m'; cy='\e[1;96m'; w='\e[1;97m'; endc='\e[0m'

# Banner Animasi
banner() {
    clear
    echo -e "${p}"
    echo "███████╗██╗███╗   ██╗ █████╗ ███╗   ██╗███████╗"
    echo "██╔════╝██║████╗  ██║██╔══██╗████╗  ██║██╔════╝"
    echo "█████╗  ██║██╔██╗ ██║███████║██╔██╗ ██║█████╗  "
    echo "██╔══╝  ██║██║╚██╗██║██╔══██║██║╚██╗██║██╔══╝  "
    echo "██║     ██║██║ ╚████║██║  ██║██║ ╚████║███████╗"
    echo "╚═╝     ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝"
    echo -e "${y}     MR.FRIANS OSINT PHONE TOOL${endc}"
    echo
}

# Loading Animasi
loading() {
    echo -ne "${cy}Checking number"
    for i in {1..3}; do
        echo -ne "."
        sleep 0.5
    done
    echo -e "${endc}"
}

# API Key dari numverify.com
API_KEY="YOUR_API_KEY"  # Ganti dengan API kamu

banner
read -p "$(echo -e $g'✦ Masukkan Nomor (+62xxxx): '$endc)" nomor

loading

# Request ke API
response=$(curl -s "http://apilayer.net/api/validate?access_key=$API_KEY&number=$nomor")
valid=$(echo $response | grep -o '"valid":true')

if [[ $valid ]]; then
    negara=$(echo $response | grep -o '"country_name":"[^"]*' | cut -d'"' -f4)
    kode=$(echo $response | grep -o '"country_code":"[^"]*' | cut -d'"' -f4)
    operator=$(echo $response | grep -o '"carrier":"[^"]*' | cut -d'"' -f4)

    echo -e "${g}✔ Nomor Valid!${endc}"
    echo -e "${b}• Negara  : $negara"
    echo -e "• Kode    : +$kode"
    echo -e "• Operator: $operator${endc}"
else
    echo -e "${r}✘ Nomor tidak valid!${endc}"
fi